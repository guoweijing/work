package src.shapes;

import java.awt.Color;
import java.awt.Graphics;
import java.io.Serial;

import javax.swing.JPanel;

public abstract class Shape extends JPanel{
	
	/**
	 * 
	 */
	@Serial
	private static final long serialVersionUID = 1L;
	protected float lineSize=1.0f;
	protected Color color=Color.black;
	
	public abstract void draw(Graphics g);
	public abstract String getDesc();
	public abstract boolean contains(int a,int b);
	public abstract void increaseLineSize();
	public abstract void decreaseLineSize();
	public abstract void increaseShapeSize();
	public abstract void decreaseShapeSize();
	public void changeColor(String s) {
		switch (s) {
			case "black" -> color = Color.black;
			case "grey" -> color = Color.lightGray;
			case "turquoise" -> color = Color.blue;
			case "indigo" -> color = Color.cyan;
			case "red" -> color = Color.red;
			case "pink" -> color = Color.pink;
			case "light yellow" -> color = Color.yellow;
			case "green" -> color = Color.green;
			case "lime" -> color = new Color(173, 255, 47);
		}
	}
}



