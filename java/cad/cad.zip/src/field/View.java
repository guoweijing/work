package src.field;

import src.buttons.Buttons;
import src.picture.Picture;
import src.shapes.Circle;
import src.shapes.Line;
import src.shapes.Shape;
import src.shapes.Word;
import src.shapes.Rectangle;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.*;


public class View extends JFrame{
	/**
	 * 
	 */
	@Serial
	private static final long serialVersionUID = 1L;
	private  static  Picture pic=new Picture(1000,800);

	private  JMenuBar menuBar = new JMenuBar();
	private MouseHandler mouse = new MouseHandler();
	private Selector mouseSelector=new Selector();;
	private Shape shape;
	private String usingShape;
	private String text;
	private KeyboardHandler keyboard = new KeyboardHandler();
	private static final Buttons buttons=new Buttons();

	public View(int width,int height) {

		initial();
		this.setSize(width, height);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(true);
		this.setTitle("Mini CAD");
		this.setVisible(true);
	}
	
	public void initial() {

		JMenu menu1 = new JMenu("文件");
		JMenuItem menuItem1 = new JMenuItem("打开");
		JMenuItem menuItem2 = new JMenuItem("保存");

		menuItem1.addActionListener(new OpenFile());
		menuItem2.addActionListener(new SaveFile());

		menu1.add(menuItem1);
		menu1.add(menuItem2);
		menuBar.add(menu1);


		buttons.getDrawButton().get("Clear").addActionListener(new ClearDraw());
		buttons.getDrawButton().get("Circle").addActionListener(new DrawButtonHandler());
		buttons.getDrawButton().get("Line").addActionListener(new DrawButtonHandler());
		buttons.getDrawButton().get("Rectangle").addActionListener(new DrawButtonHandler());
		buttons.getDrawButton().get("Word").addActionListener(new DrawButtonHandler());

		for (String s : buttons.getColorButton().keySet()) {
			buttons.getColorButton().get(s).addActionListener(new ColorChange());
		}
		setJMenuBar(menuBar);
		this.getContentPane().add(buttons,BorderLayout.EAST);
		this.getContentPane().add(pic,BorderLayout.CENTER);
	}
	
	private void activateKeyboard() {
		pic.addKeyListener(keyboard);
		pic.requestFocus();
	}
	
	private void activateSelector() {
		pic.addMouseListener(mouseSelector);
		pic.addMouseMotionListener(mouseSelector);
		pic.requestFocus();
	}
	
	private void closeSelector() {
		pic.removeMouseListener(mouseSelector);
		pic.removeMouseMotionListener(mouseSelector);
	}
	
	private void activateMouseListener() {
		pic.addMouseListener(mouse);
		pic.addMouseMotionListener(mouse); 
		pic.requestFocus();
	}
	
	private void closeMouseListener() {
		pic.removeMouseListener(mouse);
		pic.removeMouseMotionListener(mouse);
	}
	
	private class KeyboardHandler implements KeyListener{

		@Override
		public void keyPressed(KeyEvent e) {
			char key=e.getKeyChar();
			if(key=='q')
			{
				shape.decreaseLineSize();
			}
			else if(key=='a')
			{
				shape.increaseLineSize();
			}
			else if(key=='w')
			{
				shape.increaseShapeSize();
			}
			else if(key=='s') {
				shape.decreaseShapeSize();
			}
			else if(key=='d')
			{
				pic.getListShape().remove(shape);
			}
			pic.repaint();
		}

		@Override
		public void keyReleased(KeyEvent e) {
			
		}

		@Override
		public void keyTyped(KeyEvent e) {
			
		}
		
	}
	
	private class Selector implements MouseMotionListener, MouseListener{
		private int[] x=new int[2];
		private int[] y=new int[2];
		boolean shapeSelected=false;
		int dx,dy;
		@Override
		public void mouseClicked(MouseEvent e) {
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {

		}

		@Override
		public void mouseExited(MouseEvent e) {
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			for(int i=0;i<pic.getListShape().size();i++)
			{	
				if(pic.getListShape().get(i).contains(e.getX(),e.getY()))
				{
					shape=pic.getListShape().get(i);
					x[0]=e.getX();
					y[0]=e.getY();
					shapeSelected=true;
					activateKeyboard();
					break;
				}
			}
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			shapeSelected=false;
		}

		@Override
		public void mouseDragged(MouseEvent e) {

			if (shapeSelected)
			{
				x[1]=e.getX();
				y[1]=e.getY();
				dx=x[1]-x[0];
				dy=y[1]-y[0];
				if(shape.getDesc().equals("Circle"))
				{
					((Circle)shape).moveCircle(dx, dy);;
				}
				else if(shape.getDesc().equals("Line"))
				{
					((Line)shape).moveLine(dx,dy);
				}
				else if(shape.getDesc().equals("Rectangle"))
				{
					((Rectangle)shape).moveRectangle(dx, dy);;
				}
				else if(shape.getDesc().equals("Word"))
				{
					((Word)shape).moveWord(dx, dy,((Word)shape).getFontSize());
				}
				x[0]=x[1];
				y[0]=y[1];
				pic.repaint();
			}
		}

		@Override
		public void mouseMoved(MouseEvent e) {
			
		}
		
	}
	
	private class MouseHandler implements MouseMotionListener, MouseListener{
		private int[] x=new int[2];
		private int[] y=new int[2];
		@Override
		public void mouseDragged(MouseEvent e) {
			x[1]=e.getX();
			y[1]=e.getY();
			switch (usingShape) {
				case "Line" -> ((Line) shape).updateLine(x[0], y[0], x[1], y[1]);
				case "Circle" -> {
					int r = (int) ((Math.sqrt((x[0] - x[1]) * (x[0] - x[1]) + (y[0] - y[1]) * (y[0] - y[1]))) / 2.0);
					((Circle) shape).updateCircle((x[0] + x[1]) / 2, (y[0] + y[1]) / 2, r);
				}
				case "Rectangle" ->
						((Rectangle) shape).updateRectangle(x[0], y[0], Math.abs(x[0] - x[1]), Math.abs(y[0] - y[1]));
				case "Word" ->
						((Word) shape).updateWord(x[0], y[0], (int) Math.sqrt((x[0] - x[1]) * (x[0] - x[1]) + (y[0] - y[1]) * (y[0] - y[1])));
			}
			pic.repaint();
		}

		@Override
		public void mouseMoved(MouseEvent e) {
			
		}

		@Override
		public void mouseClicked(MouseEvent e) {
			                   
		}

		@Override
		public void mouseEntered(MouseEvent e) {

			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			x[0]=e.getX();
			y[0]=e.getY();
			switch (usingShape) {
				case "Circle" -> shape = new Circle(0, 0, 0);
				case "Line" -> shape = new Line(1, 1, 2, 2);
				case "Rectangle" -> shape = new Rectangle(0, 0, 0, 0);
				case "Word" -> shape = new Word(0, 0, text);
			}
			pic.add(shape);
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			closeMouseListener();
			activateSelector();
		}
		
	}
	
	private class DrawButtonHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			//usingShape=((JButton)(e.getSource())).getText();
			usingShape = e.getActionCommand();
			closeSelector();
			activateMouseListener();
			if (usingShape.equals("Word"))
			text=JOptionPane.showInputDialog(pic, "输入文字","输入对话框", JOptionPane.PLAIN_MESSAGE);
		}
		
	}
	
	public class ColorChange implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
				if (shape!=null)
				{
				shape.changeColor(((JButton)(e.getSource())).getText());
				pic.repaint();
				}
		}
		
	}
	public class ClearDraw implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			ArrayList<Shape> s = new ArrayList<>();
			pic.setListShape(s);
			pic.repaint();
		}
	}

	
	public class SaveFile implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			JFileChooser chooser=new JFileChooser();
			chooser.showSaveDialog(null);
			chooser.setDialogTitle("保存文件");
			File file = chooser.getSelectedFile();

			if(file == null) {
				JOptionPane.showMessageDialog(null,"未选择文件!");
			}
			else {
				try {
					ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file));
					out.writeObject(pic.getListShape());
					JOptionPane.showMessageDialog(null,"保存成功!");
					out.close();
				}
				catch (IOException a) {
					a.printStackTrace();
					JOptionPane.showMessageDialog(null,"保存失败!");
				}
			}
		}
	}
	public class OpenFile implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			int value = JOptionPane.showConfirmDialog(null, "是否保存文件", "提示信息", 0);
			if(value == 0) {
				new SaveFile();
			}
			try {
				//?????????????????????????
				JFileChooser chooser = new JFileChooser();
				chooser.setDialogTitle("打开cad文件");
				chooser.showOpenDialog(null);
				File file = chooser.getSelectedFile();

				if(file==null){
					JOptionPane.showMessageDialog(null, "未选择文件!");
				}
				else {
					ObjectInputStream in = new ObjectInputStream(new FileInputStream(file));
					//Controller.model.setAll((ArrayList<Shape>)in.readObject());
					pic.setListShape((ArrayList<Shape>)in.readObject());
					//Controller.updateView();
					pic.repaint();
					in.close();
				}

			}
			catch (Exception e1) {
				e1.printStackTrace();
				JOptionPane.showMessageDialog(null,"打开失败!");
			}
		}
	}
	public static void main(String args[]) {
		View theView=new View(1600,800);
	}
}
